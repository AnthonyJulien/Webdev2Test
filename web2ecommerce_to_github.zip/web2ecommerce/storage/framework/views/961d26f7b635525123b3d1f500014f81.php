 



<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>



        <table>
            <tr><td>Dear <?php echo e($name); ?>,</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Please click on below link to activate your Multi-vendor E-commerce Application account:-</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td><a href="<?php echo e(url('/user/confirm/' . $code)); ?>">Confirm Account</a></td></tr> 
            <tr><td>&nbsp;</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Thanks & Regards,</td></tr>
            <tr><td>Multi-vendor E-commerce Application</td></tr>
        </table>



    </body>
</html><?php /**PATH C:\git\web2ecommerce_reset_password_ok_user_vendor\web2ecommerce\resources\views/emails/confirmation.blade.php ENDPATH**/ ?>