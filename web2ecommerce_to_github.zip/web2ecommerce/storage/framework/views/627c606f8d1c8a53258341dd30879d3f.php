<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Home Page Banners</h4>
                            


                            
                            <a href="<?php echo e(url('admin/add-edit-banner')); ?>" style="max-width: 150px; float: right; display: inline-block" class="btn btn-block btn-primary">Add Banner</a>


                            
                            
                            
                            <?php if(Session::has('success_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>


                            <div class="table-responsive pt-3">
                                
                                <table id="banners" class="table table-bordered"> 
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Image</th>
                                            <th>Type</th>
                                            <th>Link</th>
                                            <th>Title</th>
                                            <th>Alt</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($banner['id']); ?></td>
                                                <td>
                                                    <img style="width: 180px" src="<?php echo e(asset('front/images/banner_images/' . $banner['image'])); ?>">
                                                </td>
                                                <td><?php echo e($banner['type']); ?></td>
                                                <td><?php echo e($banner['link']); ?></td>
                                                <td><?php echo e($banner['title']); ?></td>
                                                <td><?php echo e($banner['alt']); ?></td>
                                                <td>
                                                    <?php if($banner['status'] == 1): ?>
                                                        <a class="updateBannerStatus" id="banner-<?php echo e($banner['id']); ?>" banner_id="<?php echo e($banner['id']); ?>" href="javascript:void(0)"> 
                                                            <i style="font-size: 25px" class="mdi mdi-bookmark-check" status="Active"></i> 
                                                        </a>
                                                    <?php else: ?> 
                                                        <a class="updateBannerStatus" id="banner-<?php echo e($banner['id']); ?>" banner_id="<?php echo e($banner['id']); ?>" href="javascript:void(0)"> 
                                                            <i style="font-size: 25px" class="mdi mdi-bookmark-outline" status="Inactive"></i> 
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(url('admin/add-edit-banner/' . $banner['id'])); ?>">
                                                        <i style="font-size: 25px" class="mdi mdi-pencil-box"></i> 
                                                    </a>

                                                    
                                                    
                                                         
                                                    
                                                    <a href="JavaScript:void(0)" class="confirmDelete" module="banner" moduleid="<?php echo e($banner['id']); ?>"> 
                                                        <i style="font-size: 25px" class="mdi mdi-file-excel-box"></i> 
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2024. All rights reserved.</span>
            </div>
        </footer>
        <!-- partial -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\git\laravel-multi-vendor-e-commerce-application-main\resources\views/admin/banners/banners.blade.php ENDPATH**/ ?>