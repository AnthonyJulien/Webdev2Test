<!-- partial:partials/_footer.html -->
<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2024. All rights reserved.</span>
    </div>
</footer><?php /**PATH C:\git\laravel-multi-vendor-e-commerce-application-main\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>