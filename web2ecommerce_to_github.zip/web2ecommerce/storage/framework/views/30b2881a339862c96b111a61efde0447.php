<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">


                
            
            <?php if(Session::has('error_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Error:</strong> <?php echo e(Session::get('error_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>



                
            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>


             
            
            
            
            <?php if(Session::has('success_message')): ?> <!-- Check vendorRegister() method in Front/VendorController.php -->
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>



            <div class="row">
                <div class="col-md-12 grid-margin">
                    <div class="row">
                        <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                            <h3 class="font-weight-bold">Order Details</h3>
                            <h6 class="font-weight-normal mb-0"><a href="<?php echo e(url('admin/orders')); ?>">Back to Orders</a></h6>
                        </div>
                        <div class="col-12 col-xl-4">
                            <div class="justify-content-end d-flex">
                                <div class="dropdown flex-md-grow-1 flex-xl-grow-0">
                                    <button class="btn btn-sm btn-light bg-white dropdown-toggle" type="button" id="dropdownMenuDate2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    <i class="mdi mdi-calendar"></i> Today (10 Jan 2021)
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuDate2">
                                        <a class="dropdown-item" href="#">January - March</a>
                                        <a class="dropdown-item" href="#">March - June</a>
                                        <a class="dropdown-item" href="#">June - August</a>
                                        <a class="dropdown-item" href="#">August - November</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Order Details</h4>
                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Order ID: </label>
                                <label>#<?php echo e($orderDetails['id']); ?></label>
                            </div>
                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Order Date: </label>
                                <label><?php echo e(date('Y-m-d h:i:s', strtotime($orderDetails['created_at']))); ?></label>
                            </div>
                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Order Status: </label>
                                <label><?php echo e($orderDetails['order_status']); ?></label>
                            </div>
                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Order Total: </label>
                                <label>EGP<?php echo e($orderDetails['grand_total']); ?></label>
                            </div>
                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Shipping Charges: </label>
                                <label>EGP<?php echo e($orderDetails['shipping_charges']); ?></label>
                            </div>

                            <?php if(!empty($orderDetails['coupon_code'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">Coupon Code: </label>
                                    <label><?php echo e($orderDetails['coupon_code']); ?></label>
                                </div>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">Coupon Amount: </label>
                                    <label>EGP<?php echo e($orderDetails['coupon_amount']); ?></label>
                                </div>                                
                            <?php endif; ?>

                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Payment Method: </label>
                                <label><?php echo e($orderDetails['payment_method']); ?></label>
                            </div>
                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Payment Gateway: </label>
                                <label><?php echo e($orderDetails['payment_gateway']); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Customer Details</h4>
                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Name: </label>
                                <label><?php echo e($userDetails['name']); ?></label>
                            </div>

                            <?php if(!empty($userDetails['address'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">Address: </label>
                                    <label><?php echo e($userDetails['address']); ?></label>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($userDetails['city'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">City: </label>
                                    <label><?php echo e($userDetails['city']); ?></label>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($userDetails['state'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">State: </label>
                                    <label><?php echo e($userDetails['state']); ?></label>
                                </div>
                            <?php endif; ?>
                            
                            <?php if(!empty($userDetails['country'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">Country: </label>
                                    <label><?php echo e($userDetails['country']); ?></label>
                                </div>
                            <?php endif; ?>
                            
                            <?php if(!empty($userDetails['pincode'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">Pincode: </label>
                                    <label><?php echo e($userDetails['pincode']); ?></label>
                                </div>
                            <?php endif; ?>

                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Mobile: </label>
                                <label><?php echo e($userDetails['mobile']); ?></label>
                            </div>
                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Email: </label>
                                <label><?php echo e($userDetails['email']); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Delivery Address</h4>
                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Name: </label>
                                <label><?php echo e($orderDetails['name']); ?></label>
                            </div>

                            <?php if(!empty($orderDetails['address'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">Address: </label>
                                    <label><?php echo e($orderDetails['address']); ?></label>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($orderDetails['city'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">City: </label>
                                    <label><?php echo e($orderDetails['city']); ?></label>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($orderDetails['state'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">State: </label>
                                    <label><?php echo e($orderDetails['state']); ?></label>
                                </div>
                            <?php endif; ?>
                            
                            <?php if(!empty($orderDetails['country'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">Country: </label>
                                    <label><?php echo e($orderDetails['country']); ?></label>
                                </div>
                            <?php endif; ?>
                            
                            <?php if(!empty($orderDetails['pincode'])): ?>
                                <div class="form-group" style="height: 15px">
                                    <label style="font-weight: 550">Pincode: </label>
                                    <label><?php echo e($orderDetails['pincode']); ?></label>
                                </div>
                            <?php endif; ?>

                            <div class="form-group" style="height: 15px">
                                <label style="font-weight: 550">Mobile: </label>
                                <label><?php echo e($orderDetails['mobile']); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Update Order Status</h4>  

                             
                            <?php if(Auth::guard('admin')->user()->type != 'vendor'): ?>   
                                
                                
                                <form action="<?php echo e(url('admin/update-order-status')); ?>" method="post">  
                                    <?php echo csrf_field(); ?> 

                                    <input type="hidden" name="order_id" value="<?php echo e($orderDetails['id']); ?>">

                                    <select name="order_status" id="order_status" required>
                                        <option value="" selected>Select</option>
                                        <?php $__currentLoopData = $orderStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status['name']); ?>"  <?php if(!empty($orderDetails['order_status']) && $orderDetails['order_status'] == $status['name']): ?> selected <?php endif; ?>><?php echo e($status['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    
                                    <input type="text" name="courier_name"    id="courier_name"    placeholder="Courier Name">    
                                    <input type="text" name="tracking_number" id="tracking_number" placeholder="Tracking Number"> 

                                    <button type="submit">Update</button>
                                </form>
                                <br>

                                
                                <?php $__currentLoopData = $orderLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        // echo '<pre>', var_dump($log), '</pre>';
                                        // echo '<pre>', var_dump($log['orders_products']), '</pre>';
                                        // echo '<pre>', var_dump($key), '</pre>';
                                        // echo '<pre>', var_dump($log['orders_products'][$key]), '</pre>';
                                        // echo '<pre>', var_dump($log['orders_products'][$key]['product_code']), '</pre>';
                                    ?>

                                    <strong><?php echo e($log['order_status']); ?></strong>

                                    
                                    <?php if($orderDetails['is_pushed'] == 1): ?> 
                                        <span style="color: green">(Order Pushed to Shiprocket)</span>
                                    <?php endif; ?>

                                    

                                    
                                    <?php if(isset($log['order_item_id']) && $log['order_item_id'] > 0): ?> 
                                        <?php
                                            $getItemDetails = \App\Models\OrdersLog::getItemDetails($log['order_item_id']);
                                        ?>
                                        - for item <?php echo e($getItemDetails['product_code']); ?>


                                        <?php if(!empty($getItemDetails['courier_name'])): ?>
                                            <br>
                                            <span>Courier Name: <?php echo e($getItemDetails['courier_name']); ?></span>
                                        <?php endif; ?>

                                        <?php if(!empty($getItemDetails['tracking_number'])): ?>
                                            <br>
                                            <span>Tracking Number: <?php echo e($getItemDetails['tracking_number']); ?></span>
                                        <?php endif; ?>

                                    <?php endif; ?>

                                    <br>
                                    <?php echo e(date('Y-m-d h:i:s', strtotime($log['created_at']))); ?>

                                    <br>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?> 
                                This feature is restricted.
                            <?php endif; ?>

                        </div>
                    </div>
                </div>

                
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Ordered Products</h4>

                            <div class="table-responsive">
                                
                                <table class="table table-striped table-borderless">
                                    <tr class="table-danger">
                                        <th>Product Image</th>
                                        <th>Code</th>
                                        <th>Name</th>
                                        <th>Size</th>
                                        <th>Color</th>
                                        <th>Unit Price</th> 
                                        <th>Product Qty</th>
                                        <th>Total Price</th> 

                                        
                                        <?php if(\Illuminate\Support\Facades\Auth::guard('admin')->user()->type != 'vendor'): ?>  
                                            <th>Product by</th>
                                        <?php endif; ?>

                                        
                                        
                                        <th>Commission</th> 
                                        <th>Final Amount</th> 

                                        <th>Item Status</th>  
                                        
                                    </tr>

                                    <?php $__currentLoopData = $orderDetails['orders_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php
                                                    $getProductImage = \App\Models\Product::getProductImage($product['product_id']);
                                                ?>

                                                <a target="_blank" href="<?php echo e(url('product/' . $product['product_id'])); ?>">
                                                    <img src="<?php echo e(asset('front/images/product_images/small/' . $getProductImage)); ?>">
                                                </a>
                                            </td>
                                            <td><?php echo e($product['product_code']); ?></td>
                                            <td><?php echo e($product['product_name']); ?></td>
                                            <td><?php echo e($product['product_size']); ?></td>
                                            <td><?php echo e($product['product_color']); ?></td>
                                            <td><?php echo e($product['product_price']); ?></td> 
                                            <td><?php echo e($product['product_qty']); ?></td>
                                            <td>
                                                
                                                <?php if($product['vendor_id'] > 0): ?> 

                                                    
                                                    <?php if($orderDetails['coupon_amount'] > 0): ?> 

                                                        <?php if(\App\Models\Coupon::couponDetails($orderDetails['coupon_code'])['vendor_id'] > 0): ?> 
                                                            <?php
                                                                // dd(\App\Models\Coupon::couponDetails($orderDetails['coupon_code'])['vendor_id']);    
                                                            ?>
                                                            
                                                        <?php echo e($total_price = ($product['product_price'] * $product['product_qty']) - $item_discount); ?>

                                                        <?php else: ?> 
                                                            <?php echo e($total_price = $product['product_price'] * $product['product_qty']); ?>

                                                        <?php endif; ?>
                                                    
                                                    <?php else: ?> 
                                                        <?php echo e($total_price = $product['product_price'] * $product['product_qty']); ?>

                                                    <?php endif; ?>

                                                <?php else: ?> 
                                                    <?php echo e($total_price = $product['product_price'] * $product['product_qty']); ?>

                                                <?php endif; ?>
                                            </td>  

                                            
                                            <?php if(\Illuminate\Support\Facades\Auth::guard('admin')->user()->type != 'vendor'): ?>  
                                                <?php if($product['vendor_id'] > 0): ?> 
                                                    <td>
                                                        <a href="/admin/view-vendor-details/<?php echo e($product['admin_id']); ?>" target="_blank">Vendor</a>
                                                    </td>
                                                <?php else: ?>
                                                    <td>Admin</td>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            
                                            
                                            <?php if($product['vendor_id'] > 0): ?> 
                                                <td><?php echo e($commission = round($total_price * $product['commission'] / 100, 2)); ?></td> 
                                                <td><?php echo e($total_price - $commission); ?></td>
                                            <?php else: ?>
                                                <td>0</td>
                                                <td><?php echo e($total_price); ?></td>
                                            <?php endif; ?>

                                            
                                            <td>
                                                
                                                
                                                <form action="<?php echo e(url('admin/update-order-item-status')); ?>" method="post">  
                                                    <?php echo csrf_field(); ?> 

                                                    <input type="hidden" name="order_item_id" value="<?php echo e($product['id']); ?>">

                                                    <select id="order_item_status" name="order_item_status" required>
                                                        <option value="">Select</option>
                                                        <?php $__currentLoopData = $orderItemStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($status['name']); ?>"  <?php if(!empty($product['item_status']) && $product['item_status'] == $status['name']): ?> selected <?php endif; ?>><?php echo e($status['name']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                    
                                                    <input style="width: 110px" type="text" name="item_courier_name"    id="item_courier_name"    placeholder="Item Courier Name"    <?php if(!empty($product['courier_name'])): ?>    value="<?php echo e($product['courier_name']); ?>"    <?php endif; ?>> 
                                                    <input style="width: 110px" type="text" name="item_tracking_number" id="item_tracking_number" placeholder="Item Tracking Number" <?php if(!empty($product['tracking_number'])): ?> value="<?php echo e($product['tracking_number']); ?>" <?php endif; ?>> 

                                                    <button type="submit">Update</button>
                                                </form>
                                            </td>
                                        </tr>         
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
        <!-- content-wrapper ends -->

        
        <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\git\web2ecommerce\resources\views/admin/orders/order_details.blade.php ENDPATH**/ ?>