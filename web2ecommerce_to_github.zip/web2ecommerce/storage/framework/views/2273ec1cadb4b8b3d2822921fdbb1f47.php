<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Products</h4>



                            
                            <a href="<?php echo e(url('admin/add-edit-product')); ?>" style="max-width: 150px; float: right; display: inline-block" class="btn btn-block btn-primary">Add Product</a>

                            
                            
                            
                            <?php if(Session::has('success_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>


                            <div class="table-responsive pt-3">
                                
                                <table id="products" class="table table-bordered"> 
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Product Name</th>
                                            <th>Product Code</th>
                                            <th>Product Color</th>
                                            <th>Product Image</th>
                                            <th>Category</th> 
                                            <th>Section</th>  
                                            <th>Added by</th> 
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($product['id']); ?></td>
                                                <td><?php echo e($product['product_name']); ?></td>
                                                <td><?php echo e($product['product_code']); ?></td>
                                                <td><?php echo e($product['product_color']); ?></td>
                                                <td>
                                                    <?php if(!empty($product['product_image'])): ?>
                                                        <img style="width:120px; height:100px" src="<?php echo e(asset('front/images/product_images/small/' . $product['product_image'])); ?>"> 
                                                    <?php else: ?>
                                                        <img style="width:120px; height:100px" src="<?php echo e(asset('front/images/product_images/small/no-image.png')); ?>"> 
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($product['category']['category_name']); ?></td> 
                                                <td><?php echo e($product['section']['name']); ?></td> 
                                                <td>
                                                    <?php if($product['admin_type'] == 'vendor'): ?>
                                                        <a target="_blank" href="<?php echo e(url('admin/view-vendor-details/' . $product['admin_id'])); ?>"><?php echo e(ucfirst($product['admin_type'])); ?></a>
                                                    <?php else: ?>
                                                        <?php echo e(ucfirst($product['admin_type'])); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($product['status'] == 1): ?>
                                                        <a class="updateProductStatus" id="product-<?php echo e($product['id']); ?>" product_id="<?php echo e($product['id']); ?>" href="javascript:void(0)"> 
                                                            <i style="font-size: 25px" class="mdi mdi-bookmark-check" status="Active"></i> 
                                                        </a>
                                                    <?php else: ?> 
                                                        <a class="updateProductStatus" id="product-<?php echo e($product['id']); ?>" product_id="<?php echo e($product['id']); ?>" href="javascript:void(0)"> 
                                                            <i style="font-size: 25px" class="mdi mdi-bookmark-outline" status="Inactive"></i> 
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a title="Edit Product" href="<?php echo e(url('admin/add-edit-product/' . $product['id'])); ?>">
                                                        <i style="font-size: 25px" class="mdi mdi-pencil-box"></i> 
                                                    </a>
                                                    <a title="Add Attributes" href="<?php echo e(url('admin/add-edit-attributes/' . $product['id'])); ?>">
                                                        <i style="font-size: 25px" class="mdi mdi-plus-box"></i> 
                                                    </a>
                                                    <a title="Add Multiple Images" href="<?php echo e(url('admin/add-images/' . $product['id'])); ?>">
                                                        <i style="font-size: 25px" class="mdi mdi-library-plus"></i> 
                                                    </a>

                                                    
                                                    
                                                         
                                                    
                                                    <a href="JavaScript:void(0)" class="confirmDelete" module="product" moduleid="<?php echo e($product['id']); ?>"> 
                                                        <i style="font-size: 25px" class="mdi mdi-file-excel-box"></i> 
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2024. All rights reserved.</span>
            </div>
        </footer>
        <!-- partial -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\git\web2ecommerce_reset_password_ok_user_vendor\web2ecommerce\resources\views/admin/products/products.blade.php ENDPATH**/ ?>