 



<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>



        <table>
            <tr><td>Dear <?php echo e($name); ?>,</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Welcome to Multi-vendor E-commerce Application. Your account has been successfully created with below information:</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Name: <?php echo e($name); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Mobile: <?php echo e($mobile); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Email: <?php echo e($email); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Password: ****** (as chosen by you)</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Thanks & Regards,</td></tr>
            <tr><td>Multi-vendor E-commerce Application</td></tr>
        </table>



    </body>
</html><?php /**PATH C:\git\web2ecommerce_reset_password_ok_user_vendor\web2ecommerce\resources\views/emails/register.blade.php ENDPATH**/ ?>